import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.filechooser.*;

public class MainFrame extends JFrame {
	ArrayList<MyFile> list = new ArrayList<MyFile>();
	JTextArea resultWindow;
	JTabbedPane pane;
	int index = 0;

	MainFrame() {
		// 메뉴바 생성
		createMenu();

		this.setLayout(new BorderLayout(0, 1));

		// 탭팬 생성
		pane = new JTabbedPane();
		pane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				pane.setFocusable(true);
			}
		});
		this.add(pane, BorderLayout.CENTER);

		// Window 생성
		resultWindow = new JTextArea(10, 50);
		this.add(new JScrollPane(resultWindow), BorderLayout.SOUTH);

		// 기본 설정
		setTitle("Compiler");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500, 800);
		setVisible(true);
	}

	class myActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String str = e.getActionCommand();
			Commander cmd = new Commander();
			int i = pane.getSelectedIndex();

			if (str.equals("Open")) {
				JFileChooser chooser = new JFileChooser();
				chooser.setFileFilter(new FileNameExtensionFilter("java Files", "java"));
				int ret = chooser.showOpenDialog(null);

				if (ret != JFileChooser.APPROVE_OPTION) {
					resultWindow.setText("Open Failed");
					return;
				}

				String path = chooser.getSelectedFile().getPath();
				String name = chooser.getSelectedFile().getName();
				// 탭팬 중복 방지
				for (MyFile f : list) {
					if (path.equals(f.getPath())) {
						resultWindow.setText("File Name is Duplicated");
						return;
					}
				}

				list.add(new MyFile(path, name));
				cmd.open(path);
				list.get(index).setEditWindow(cmd.popResult());
				pane.addTab(name, new JScrollPane(list.get(index).getEditWindow()));
				index++;

			} else if (str.equals("Close")) {
				try {
					pane.remove(i);
					list.remove(i);
					index--;
				} catch (Exception ex) {
					return;
				}

			} else if (str.equals("Save")) {
				int result = JOptionPane.showConfirmDialog(null, "저장하시겠습니까?", "Save", JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION)
					try {
						MyFile mf = list.get(pane.getSelectedIndex());
						File f = new File(mf.getPath());
						BufferedWriter bw = new BufferedWriter(new FileWriter(f));
						String text = mf.getEditWindow().getText();
						bw.write(text, 0, text.length());
						bw.flush();
						bw.close();
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "파일을 선택하세요", "오류", JOptionPane.ERROR_MESSAGE);
						return;
					}

			} else if (str.equals("SaveAs")) {
				JFileChooser chooser = new JFileChooser();
				int ret = chooser.showSaveDialog(null);
				try {
					if (ret == JFileChooser.APPROVE_OPTION) {
						MyFile mf = list.get(pane.getSelectedIndex());
						String path = chooser.getSelectedFile().getPath();
						File f = new File(path);
						if (f.exists()) {
							JOptionPane.showMessageDialog(null, "이미 존재하는 파일입니다", "오류", JOptionPane.ERROR_MESSAGE);
							return;
						}
						BufferedWriter bw = new BufferedWriter(new FileWriter(f));
						String text = mf.getEditWindow().getText();
						bw.write(text, 0, text.length());
						bw.flush();
						bw.close();
					}
				} catch (ArrayIndexOutOfBoundsException e1) {
					JOptionPane.showMessageDialog(null, "파일을 선택하세요", "오류", JOptionPane.ERROR_MESSAGE);
				} catch (IOException e2) {
					JOptionPane.showMessageDialog(null, "알수 없는 오류", "오류", JOptionPane.ERROR_MESSAGE);
				}
			}

			else if (str.equals("Compile"))
				try {
					resultWindow.setText(cmd.compile(list.get(i).getPath()));
				} catch (Exception ex) {
					return;
				}
			else if (str.equals("Quit"))
				System.exit(0);

		}
	}

	public static void main(String args[]) {
		new MainFrame();
	}

	void createMenu() {
		JMenuItem item[] = new JMenuItem[6];
		String itemName[] = { "Open", "Close", "Save", "SaveAs", "Quit", "Compile" };

		// 메뉴 바
		JMenuBar mb = new JMenuBar();

		// 메뉴 (메뉴바의 컴포넌트)
		JMenu fileMenu = new JMenu("File");
		JMenu runMenu = new JMenu("Run");

		// fileMenu 컴포넌트 구성
		for (int i = 0; i < 6; i++) {
			item[i] = new JMenuItem(itemName[i]);
			item[i].addActionListener(new myActionListener());
		}

		item[0].setAccelerator(KeyStroke.getKeyStroke('T', KeyEvent.CTRL_MASK)); // Open tab
		item[1].setAccelerator(KeyStroke.getKeyStroke('W', KeyEvent.CTRL_MASK)); // Close tab
		item[2].setAccelerator(KeyStroke.getKeyStroke('S', KeyEvent.CTRL_MASK)); // Save
		item[3].setAccelerator(KeyStroke.getKeyStroke('S', KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK)); // Save
		item[4].setAccelerator(KeyStroke.getKeyStroke('Q', KeyEvent.CTRL_MASK)); // Quit
		item[5].setAccelerator(KeyStroke.getKeyStroke('R', KeyEvent.CTRL_MASK)); // Compile

		for (int i = 0; i < 5; i++)
			fileMenu.add(item[i]);
		runMenu.add(item[5]);

		// 메뉴 바 색상 설정 및 부착
		mb.add(fileMenu);
		mb.add(runMenu);
		mb.setBackground(Color.ORANGE);
		this.setJMenuBar(mb);
	}
}
